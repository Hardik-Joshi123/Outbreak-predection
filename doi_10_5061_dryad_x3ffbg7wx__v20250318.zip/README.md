## Analysis of clinico-demographic characteristics in PCR-confirmed patients with hepatitis B virus, hepatitis C virus, human papillomavirus, and cytomegalovirus infections at a Nepalese Reference Laboratory

[https://doi.org/10.5061/dryad.x3ffbg7wx](https://doi.org/10.5061/dryad.x3ffbg7wx)

## Description of the data and file structure

Analysis of Clinico-Demographic Characteristics in PCR-Confirmed Patients with Hepatitis B Virus, Hepatitis C Virus, Human Papillomavirus, and Cytomegalovirus Infections at a Nepalese Reference Laboratory

The dataset is of laboratory-visiting individuals with or without infection due to virus(s).

Dataset comprises of single sheet. The sheet details for demographic information, such as age group and gender of the infected and non-infected individuals; clinical information, including specimen subjected for testing, year of specimen tested, collection, molecular test performed; and histopathological assessments comprising cellular abnormalities. Considering that Patient identification number and Specimen number are human subject data and must be anonymized, these identifiers were removed in the dataset. Exact or direct age is removed and is categorized as age group to anonymize the data.

Not available (n/a) is noted for quantitative values of viral loads (e.g. HPV and CMV) or for individuals not undergoing histopathological examinations.

Data were anonymized with the code. Patients with non-fermenters infection were coded with alphanumeric number with initial Nno. (N1, N23, etc.).

Units of the study variables were standard and as follows:

(a) Age group			Years

(b) Quantitative values 	copies/mL (microgram per milliliter) (for DNA/RNA)

For HBV and HCV analysis, 5 mL of blood was collected aseptically in EDTA tubes, with plasma separated by centrifugation at 3,000 rpm for 5 minutes and either processed immediately for rtPCR or stored at -70°C. For HPV detection, cells from the exocervix and endocervical canal were collected by a gynecologic oncologist, rinsed into a tube with 5 mL of collection buffer, and sent for DNA analysis. For CMV analysis, 3-5 mL of blood, 10-20 mL of midstream urine, or 2-5 mL of sputum was collected in sterile containers, with nasopharyngeal, throat, or wound swabs in sterile tubes. Specimens were transported on ice for processing within 24 hours or frozen at -20°C to -80°C for extended storage.

Nucleic acid (DNA or RNA) extraction was performed with the extraction kits following the manufacturer's guidelines. The extracted DNA or RNA were stored at -80°C for long-term storage.

Real-time PCR assays for HBV, HCV, and CMV were conducted using commercial kits following manufacturer protocols.1-4 Reactions were set up in a 96-well format on an rtPCR thermocycler (CFX96 Touch Real-Time PCR Detection System, Bio-Rad Laboratories India Pvt. Ltd., Haryana, India), with primers and probes targeting conserved viral genomic regions. The Human Papillomavirus Nucleic Acid Amplification Test Kit [28 Types of HPV Nucleic Acid Detection Kit (Fluorescence PCR)] was used to detect HPV-16, HPV-18, and other types (16, 18, 31, 33, 35, 39, 45, 51, 52, 56, 58, 59, 66, and 68).5

Each PCR run incorporated positive and negative controls—known viral DNA/RNA as positives and nuclease-free water as negatives—to ensure assay accuracy. A standard curve from serial viral RNA/DNA dilutions allowed precise viral load quantification. Fluorescent readings at each annealing step enabled automated analysis of amplification plots, with an internal control (IC) detecting any rtPCR inhibitors. Results were validated upon successful IC amplification.

Results were confirmed if HBV DNA was >50 IU/ml, HCV RNA was >25 IU/ml, HPV DNA was >25 IU/ml, or CMV DNA was >25 IU/ml.

Pap smear specimens were collected via ectocervical and endocervical scraping, smeared onto slides, spray-fixed, and transported to the cytohistology laboratory. Slides were rehydrated, stained with hematoxylin for nuclear detail, followed by OG-6 and light green SF-eosin for cytoplasmic staining, mounted in DPX, and examined microscopically by pathologists using the 2001 Bethesda system.6

Demographic data (age, gender), clinical details (specimen type, histopathology), and molecular findings (viral load, genotype) were collected in the patient information sheets from electronic medical records (Hospital Information & Management System, ITDOSE INFOSYSTEMS Pvt. Ltd.), with any unclear entries verified through healthcare providers, patients, or families using listed contact information. All variables were documented in Microsoft Excel version 15.0. Data was entered and managed using Microsoft Excel, version 2016, and analyzed using Statistical Package for Social Sciences (SPSS), version 17.0. Descriptive data were analyzed in terms of frequency and percentage. Quantitative data were reported as mean, median, and interquartile range (IQR). A p-value of <0.05 within a 95% confidence interval (CI).

n/a represents not available, 0 represents female, 1 represents male, HBV=Hepatiis B virus, HCV=Hepatiis C virus, CMV=Cytomegalovirus, HPV=Human papillomavirus, DNA=Deoxyribose nucleic acid, RNA=Ribose nucleic acid, ASC-H=atypical squamous cells, ASC-US=atypical squamous cells of undetermined significance, HSIL=high-grade squamous intraepithelial lesion

Readers may access the data from the Dryad repository or with a request email to the author, Ajaya Basnet (abasnet.microberesearch@gmail), of the article.

References

\[1]	Nucleic acid extraction reagent. Uni-Medica. China. Available on [https://www.uni-medica.com/EN/ProductDetails?keyword=7ecaed4d-cb8f-44d2-98f4-cf20e1bda85a&menuPid=31&menuSid=36](https://www.uni-medica.com/EN/ProductDetails?keyword=7ecaed4d-cb8f-44d2-98f4-cf20e1bda85a&menuPid=31&menuSid=36) (accessed on 11/15/2024)

\[2]	Quantiplus® HBV FAST RTPCR Kit (Real-Time Quantitative PCRKit). Available from [https://huwellife.com/wp-content/uploads/2023/11/Reference-guide-6.pdf](https://huwellife.com/wp-content/uploads/2023/11/Reference-guide-6.pdf) (accessed on 11/15/2024)

\[3]	Quantiplus® HCV FAST RT PCR Kit (Real-Time Quantitative PCR Kit). Available from [https://huwellife.com/safety-sheets/quantiplus-hcv-fast-rt-pcr-kit-real-time-quantitative-pcr-kit/](https://huwellife.com/safety-sheets/quantiplus-hcv-fast-rt-pcr-kit-real-time-quantitative-pcr-kit/) (accessed on 11/15/2024)

\[4]	Quantiplus® CMV FAST RT PCR Kit (Real-Time QuantitativePCRKit). Available from [https://huwellife.com/wp-content/uploads/2023/11/Reference-Guide-3.pdf](https://huwellife.com/wp-content/uploads/2023/11/Reference-Guide-3.pdf) (accessed on 11/15/2024)

\[5]	High Quality for Hpv Genotyping Pcr - 28 Types of HPV Nucleic Acid Detection Kit (Fluorescence PCR ) – Macro & Micro-Test. Jiangsu Macro & Micro-Test Med-Tech Co., Ltd. Available from: [https://www.mmtest.com/high-quality-for-hpv-genotyping-pcr-28-types-of-hpv-nucleic-acid-detection-kit-fluorescence-pcr-macro-micro-test-3-product/](https://www.mmtest.com/high-quality-for-hpv-genotyping-pcr-28-types-of-hpv-nucleic-acid-detection-kit-fluorescence-pcr-macro-micro-test-3-product/) (accessed on 11/15/2024)

\[6]	Solomon D, Davey D, Kurman R, Moriarty A, O'Connor D, Prey M, Raab S, Sherman M, Wilbur D, Wright Jr T, Young N. The 2001 Bethesda System: terminology for reporting results of cervical cytology. Jama. 2002 Apr 24;287(16):2114-9.
