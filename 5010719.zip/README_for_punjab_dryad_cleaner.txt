Variables contained in the dataset:

hcv - A binary variable that describes whether or not that person tested positive for HCV antibodies (as opposed to negative).

hcv_rna - A binary variable that describes whether or not that person tested positive for HCV RNA (as opposed to negative).

female - A binary variable that describes whether or not that person is female (as opposed to male).

age_group - A categorial variable from 0-5 describing the age group of the respondent. The categories correspond to the following age groups: 0 is 5-18 years old, 1 is 19-29 years old, 2 is 30-39 years old, 3 is 40-49 years old, 4 is 50-59 years old, 5 is 60 years or older.

rural - A binary variable that describes whether or not that person lives in a rural area (as opposed to urban).

last_injection_giver - A categorical variable from 1-3 describing who administered the last medical injection that person received. Category 1 corresponds to a "Medical doctor", category 2 corresponds to a "Registered Nurse/Medical Practitioner", and category 3 corresponds to "Other/Chemist/Unlicensed/Unknown".

education_level - A categorical variable from 1-3 describing the highest completed education level of the respondent. Category 1 responds to "None/Primary", category 2 responds to "Middle/Secondary", and category 3 responds to "Graduate".
