# Countries where guinea worm disease is endemic - Data package

This data package contains the data that powers the chart ["Countries where guinea worm disease is endemic"](https://ourworldindata.org/grapher/progress-towards-guinea-worm-disease-eradication?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on March 18, 2025.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Certification status over time
The current and historical values for the status of [Guinea worm disease (Dracunculiasis)](#dod:guinea-worm) as certified by the WHO. To be certified as free of guinea worm disease, a country must have reported zero indigenous cases through active surveillance for at least three consecutive years.
Last updated: June 17, 2024  
Next update: June 2025  
Date range: 1996–2023  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
World Health Organization (2024) – with major processing by Our World in Data

#### Full citation
World Health Organization (2024) – with major processing by Our World in Data. “Certification status over time – WHO” [dataset]. World Health Organization, “Certification status of dracunculiasis eradication” [original data].
Source: World Health Organization (2024) – with major processing by Our World In Data

### What you should know about this data
* A country has to have no cases of guinea worm disease for three years while being actively surveilled to be "certified disease free".
* A disease outbreak is endemic in a country if it is consistently present in the country. Countries labeled pre-certification are endemic countries that have reported zero indigenous cases in the calendar year. Countries labeled pending surveillance have not had sufficient testing to determine their status or the number of cases in the country.

### How is this data described by its producer - World Health Organization (2024)?
Elimination of [dracunculiasis[(#dod:guinea-worm)] is the confirmed absence of the emergence of adult female worms (the interruption of transmission of Dracunculus medinensis) in humans and animals for three consecutive years or longer from a country with such a low risk of reintroduction of the parasite that preventive measures could be reduced to a strict minimum.

### Source

#### World Health Organization – Certification status of dracunculiasis eradication
Retrieved on: 2024-06-17  
Retrieved from: https://web.archive.org/web/20211024081702/https://apps.who.int/dracunculiasis/dradata/html/report_Countries_t0.html  

#### Notes on our processing step for this indicator
The current and historical values for the status of Guinea worm disease (Dracunculiasis) as certified by the WHO. To be certified as free of guinea worm disease, a country must have reported zero indigenous cases through active surveillance for at least three consecutive years.
Data regarding certification status is available at the WHO: https://web.archive.org/web/20211024081702/https://apps.who.int/dracunculiasis/dradata/html/report_Countries_t0.html
We have added the recent changes to Guinea worm disease certification: - Angola has had endemic statuss since 2020:  https://www.who.int/news/item/23-09-2020-eradicating-dracunculiasis-human-cases-and-animal-infections-decline-as-angola-becomes-endemic - Kenya was certified guinea worm free in 2018: https://www.who.int/news/item/21-03-2018-dracunculiasis-eradication-south-sudan-claims-interruption-of-transmission-in-humans - DRC was certified guinea worm free in 2022: https://www.who.int/news/item/15-12-2022-the-democratic-republic-of-the-congo-certified-free-of-dracunculiasis-transmission-by-who


    