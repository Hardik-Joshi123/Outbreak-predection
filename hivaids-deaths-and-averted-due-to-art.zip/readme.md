# HIV/AIDS deaths averted by antiretroviral therapy - Data package

This data package contains the data that powers the chart ["HIV/AIDS deaths averted by antiretroviral therapy"](https://ourworldindata.org/grapher/hivaids-deaths-and-averted-due-to-art?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website.

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The remaining columns are the data columns, each of which is a time series. If the CSV data is downloaded using the "full data" option, then each column corresponds to one time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data columns are transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

### How we process data at Our World In Data
All data and visualizations on Our World in Data rely on data sourced from one or several original data providers. Preparing this original data involves several processing steps. Depending on the data, this can include standardizing country names and world region definitions, converting units, calculating derived indicators such as per capita measures, as well as adding or adapting metadata such as the name or the description given to an indicator.
[Read about our data pipeline](https://docs.owid.io/projects/etl/)

## Detailed information about each time series


## Lives saved due to ART – central estimate
The number of deaths prevented as a direct result of Antiretroviral Therapy (ART) among people living with HIV. It is calculated by comparing the observed mortality rates in individuals receiving ART to the estimated mortality rates in the absence of such treatment. This is the central estimate.
Last updated: January 22, 2025  
Date range: 1990–2023  
Unit: deaths  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Joint United Nations Programme on HIV/AIDS (2024) – with minor processing by Our World in Data

#### Full citation
Joint United Nations Programme on HIV/AIDS (2024) – with minor processing by Our World in Data. “Lives saved due to ART – central estimate” [dataset]. Joint United Nations Programme on HIV/AIDS, “Global AIDS Update” [original data].
Source: Joint United Nations Programme on HIV/AIDS (2024) – with minor processing by Our World In Data

### What you should know about this data
* Antiretroviral therapy (ART) has proven effective in lowering HIV-related illness and death rates among people living with HIV, as well as preventing the virus's transmission. Research indicates that starting treatment early, irrespective of an individual's CD4 cell count, maximizes benefits and saves lives. The World Health Organization (WHO) now advises ART for everyone diagnosed with HIV.
* Antiretroviral therapy (ART) has significantly reduced the number of AIDS-related deaths since its introduction in 1996.
* By suppressing HIV replication, ART improves the health and longevity of people living with HIV, thereby preventing deaths that would have occurred in its absence.

### Source

#### Joint United Nations Programme on HIV/AIDS – Global AIDS Update
Retrieved on: 2025-01-22  
Retrieved from: https://aidsinfo.unaids.org/  


## AIDS-related deaths – central estimate
Total number of people dying from AIDS-related causes, central estimate.
Last updated: January 22, 2025  
Date range: 1990–2023  
Unit: deaths  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Joint United Nations Programme on HIV/AIDS (2024) – with minor processing by Our World in Data

#### Full citation
Joint United Nations Programme on HIV/AIDS (2024) – with minor processing by Our World in Data. “AIDS-related deaths – central estimate” [dataset]. Joint United Nations Programme on HIV/AIDS, “Global AIDS Update” [original data].
Source: Joint United Nations Programme on HIV/AIDS (2024) – with minor processing by Our World In Data

### What you should know about this data
* AIDS-related deaths are estimated using multiple methods, including vital registration systems, surveys with verbal autopsies, and mathematical modeling tools like Spectrum.
* Mathematical models integrate various data sources, such as demographic data, HIV prevalence, antiretroviral therapy coverage, and survival assumptions, sometimes incorporating adjustments for misreporting.

### How is this data described by its producer - Joint United Nations Programme on HIV/AIDS (2024)?
The number of people dying from AIDS-related causes can be obtained using a variety of measures, including through a vital registration system adjusted for misreporting, as part of a facility- or population-based survey that may include verbal autopsy and through mathematical modelling using such tools as Spectrum. Modelling tools typically use demographic data, HIV prevalence from survey and surveillance, the number of people receiving antiretroviral therapy, HIV incidence and assumptions around survival patterns to estimate the number of people dying. In some instances, data from vital reporting systems and estimates of underreporting and misclassification also may be incorporated into these models to derive estimates of the number of AIDS-related deaths.

The source of the estimate is requested. Countries providing the number of people dying from AIDS-related causes derived from a source other than Spectrum should provide any accompanying estimates of uncertainty around this number and upload an electronic copy of the report describing how the number was calculated.

Countries should preferably report a modelled estimate rather than one derived from their vital registration system unless this system has been recently evaluated as one of high quality. Users can now opt to use their Spectrum estimate or enter nationally representative population-level data. If Spectrum estimates are chosen, the values will be pulled directly from the software once the national file is finalized.

### Source

#### Joint United Nations Programme on HIV/AIDS – Global AIDS Update
Retrieved on: 2025-01-22  
Retrieved from: https://aidsinfo.unaids.org/  


    